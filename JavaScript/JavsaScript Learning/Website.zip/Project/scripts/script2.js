function changeText() {
    document.getElementById("message").textContent = "Thanks for clicking!";
}
